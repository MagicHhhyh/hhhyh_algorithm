```c++

void exgcd(int a, int b, int &x, int &y)
{
    if (b == 0)
    {
        x = 1, y = 0;
        return;
    }
    exgcd(b, a % b, y, x);
    y -= a / b * x;
}
int inv(int x, int p)
{
    int a = x, b = p;
    int z, c;
    exgcd(a, b, z, c);
    if (z < 0)
        z += p;
    return z;
}
int f[N * 2];
int fac(int n, int x, int P)
{
    if (n <= x)
        return f[n];
    i64 res = f[x - 1];
    res = qp(res, n / x, P);
    res = res * f[n % x] % P;
    return res * fac(n / x, x, P) % P;
}
int C(int n, int m, int x, int P)
{
    int cnt = 0;
    for (int i = n; i; i /= x)
        cnt += i / x;
    for (int i = m; i; i /= x)
        cnt -= i / x;
    for (int i = n - m; i; i /= x)
        cnt -= i / x;
    return fac(n, x, P) * inv(fac(m, x, P), P) % P * inv(fac(n - m, x, P), P) % P * qp(x, cnt, P) % P;
}
int CRT(int b, int p, int P)
{
    int m = P / p;
    int invm = inv(m, p);
    return m * invm % P * b % P;
}
long long Lucas(long long n, long long m, long long p)
{
    if (m == 0)
        return 1;
    int P = p;
    int res = 0;
    for (int i = 2; i * i <= p; i++)
    {
        if (p % i == 0)
        {
            int g = 1;
            while (p % i == 0)
                p /= i, g *= i;
            f[0] = 1;
            for (int j = 1; j <= i; j++)
            {
                f[j] = j % i == 0 ? f[j - 1] : f[j - 1] * j % g;
            }
            res += CRT(C(n, m, i, g), g, P);
            res %= P;
        }
    }
    if (p > 1)
    {
        f[0] = 1;
        for (int j = 1; j <= p; j++)
        {
            f[j] = j % p == 0 ? f[j - 1] : f[j - 1] * j % p;
        }
        res += CRT(C(n, m, p, p), p, P);
        res %= P;
    }
    return res;
}
```

