### 普通静态Z函数

```c++
vector<int> Z(string s)
{
    int n = s.size();
    vector<int> z(n);
    for (int i = 1, l = 0, r = 0; i < n; i++)
    {
        if (r > i)
            z[i] = min(r - i, z[i - l]);
        while (i + z[i] < n && s[i + z[i]] == s[z[i]])
            z[i]++;
        if (i + z[i] > r)
            l = i, r = i + z[i];
    }
    return z;
}
```

### KMP动态Z拓展

```c++
  vector<int> fa(n);
    iota(all(fa), 0);
    function<int(int x)> find = [&](int x)
    {
        return fa[x] == x ? x : fa[x] = find(fa[x]);
    };
    for (int i = 0, j = 0; i < n; i++)
    {
        cin >> S[i];
        if(i==0)continue;
        //满足这种情况以i-1结尾和以nx[i-1]-1结尾是等价的
        if (i && nx[i - 1] && S[i] == S[nx[i - 1]])
        	fa[i - 1] = find(nx[i - 1] - 1);
        int p = i - 1;
        while (~p)
        {
            // 找到等价点的父节点
            if (S[p + 1] == S[i])
                p = find(p);
            // 不满足,p+1是长度，i-p-1
            if (S[p + 1] != S[i])
            {
                SB -= B[i - p - 1];
                Z[i-p-1]=p+1;
            }
            //p结尾位置的匹配前缀长度-1，找到对应的匹配位置
            p = nx[p] - 1;
        }
    }

```

