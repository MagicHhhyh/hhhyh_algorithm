

```cpp
string s;
int sa[N], x[N], y[N], c[N];
int height[N];
int n;
void SA()
{
    int m = 1e6;
    for (int i = 1; i <= n; i++)
        c[x[i] = s[i]]++;
    for (int i = 1; i <= m; i++)
        c[i] += c[i - 1];
    for (int i = n; i; i--)
        sa[c[x[i]]--] = i;
    for (int k = 1; k <= n; k <<= 1)
    {
        int p = 0;
        for (int i = n - k + 1; i <= n; i++)
            y[++p] = i;
        for (int i = 1; i <= n; i++)
            if (sa[i] > k)
                y[++p] = sa[i] - k;
        for (int i = 1; i <= m; i++)
            c[i] = 0;
        for (int i = 1; i <= n; i++)
            c[x[i]]++;
        for (int i = 1; i <= m; i++)
            c[i] += c[i - 1];
        for (int i = n; i; i--)
            sa[c[x[y[i]]]--] = y[i];
        swap(y, x);
        p = 0;
        x[sa[1]] = ++p;
        for (int i = 2; i <= n; i++)
        {
            x[sa[i]] = (y[sa[i]] == y[sa[i - 1]] && y[sa[i] + k] == y[sa[i - 1] + k]) ? p : ++p;
        }
        m = p;
        if (m == n)
            break;
    }
    for (int i = 1, j = 0; i <= n; ++i)
    {
        if (j)
            --j;
        while (s[i + j] == s[sa[x[i] - 1] + j])
            ++j;
        height[x[i]] = j;
    }
    // lcp([i...,n],[j...,n])=min([i...j])
    // 本质不同字符串个数n*(n+1)/2-sum(height)
}

```