```c++
    vector<int> dfn(n), low(n), vis(n), cyc(n);
    vector<int> st;
    vector<int> siz;
    function<void(int x, int fa)> dfs = [&](int x, int fa)
    {
        dfn[x] = low[x] = ++cnt;
        vis[x] = 1;
        st.push_back(x);
        for (auto y : e[x])
        {
            if (y == fa)
                continue;
            if (!dfn[y])
            {
                dfs(y, x);
                low[x] = min(low[x], low[y]);
            }
            else if (vis[y])
            {
                low[x] = min(low[x], dfn[y]);
            }
        }
        if (low[x] == dfn[x])
        {
            int u;
            int sz = 0;
            do
            {
                u = st.back();
                st.pop_back();
                vis[u] = 0;
                cyc[u] = x;
                sz++;
            } while (u != x);
            siz.emplace_back(sz);
        }
    };
```

