```g++
struct node
{
    int g;
    int sum;
    node operator+(const node& b)
    {
        node c = b;
        c.sum = b.sum + sum;
        c.g = gcd(g, b.g);
        return c;
    }
    void op(int x)
    {
        g = sum = x;
    }
};
```

